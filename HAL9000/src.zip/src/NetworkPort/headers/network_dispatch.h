#pragma once

FUNC_DriverDispatch             NetPortDeviceControl;

FUNC_ThreadStart                NetPortTransmitFunction;