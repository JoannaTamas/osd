#pragma once

BOOLEAN
TcBitmapRun(
    void
    );