#pragma once

FUNC_DriverDispatch          DiskDispatchReadWrite;
FUNC_DriverDispatch          DiskDispatchDeviceControl;