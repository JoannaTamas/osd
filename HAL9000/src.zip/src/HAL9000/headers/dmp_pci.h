#pragma once

#include "pci_device.h"

void
DumpPciDevice(
    IN  PPCI_DEVICE_DESCRIPTION     Device
    );