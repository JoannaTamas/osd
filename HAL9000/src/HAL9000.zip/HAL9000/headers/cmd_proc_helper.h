#pragma once

#include "cmd_common.h"

FUNC_GenericCommand CmdListProcesses;
FUNC_GenericCommand CmdProcessDump;
FUNC_GenericCommand CmdStartProcess;
FUNC_GenericCommand CmdTestProcess;