#pragma once

#include "pmm.h"

void
TestPmmReserveAndReleaseFunctions(
    void
    );