#pragma once

FUNC_DriverEntry    SystemDriverEntry;